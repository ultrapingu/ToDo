package api

import (
	"encoding/json"
	"net/http"
	"sync"

	"github.com/google/uuid"
	"github.com/gorilla/mux"
)

type TodoItem struct {
	ID   uuid.UUID `json:"id"`
	Name string    `json:"name"`
}

type Server struct {
	*mux.Router

	todoList []TodoItem
	mutex    sync.Mutex
}

func NewServer() *Server {
	s := &Server{
		Router:   mux.NewRouter(),
		todoList: []TodoItem{},
	}
	s.routes()
	return s
}

func (s *Server) routes() {
	s.HandleFunc("/items", s.listTodoItems()).Methods("GET")
	s.HandleFunc("/items", s.createTodoItem()).Methods("POST")
	s.HandleFunc("/items/{id}", s.removeTodoItem()).Methods("DELETE")
}

func (s *Server) createTodoItem() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var i TodoItem
		if err := json.NewDecoder(r.Body).Decode(&i); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		i.ID = uuid.New()

		s.mutex.Lock()
		s.todoList = append(s.todoList, i)
		s.mutex.Unlock()

		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(i); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}
}

func (s *Server) listTodoItems() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")

		s.mutex.Lock()
		err := json.NewEncoder(w).Encode(s.todoList)
		s.mutex.Unlock()

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}
}

func (s *Server) removeTodoItem() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idStr, _ := mux.Vars(r)["id"]
		id, err := uuid.Parse(idStr)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
		}

		for i, item := range s.todoList {
			if item.ID == id {
				s.mutex.Lock()
				s.todoList = append(s.todoList[:i], s.todoList[i+1:]...)
				s.mutex.Unlock()
			}
		}
	}
}
