package main

import (
	api "main/api"
	"net/http"
)

func main() {
	svr := api.NewServer()
	http.ListenAndServe(":8080", svr)
}
